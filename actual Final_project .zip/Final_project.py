
#This code is for Gui, The goal for the gui is to calulate calories needed for surplus/deficit, you can choose a path on styles building your dream body.


import tkinter as tk
from tkinter import  messagebox


#This is the main window 
window=tk.Tk()
window.geometry("560x500")
window.title("SoLo")
window["bg"] = "black"
label_1=tk.Label(window, text="Where we take You to the next LvL. ", font="calibri", bg="black",fg="#7d12ff" )
label_1.grid(column=1, row=1)
solo=tk.PhotoImage(file="Toji.png")
solo_label=tk.Label(window,image=solo,width=90,height=120,bg="black")
solo_label.grid()
solone=tk.PhotoImage(file="killua.png")
solone_label=tk.Label(window,image=solone,width=90,height=120,bg="black")
solone_label.grid(column=2,row=1)

#This where you Choose your path between path c and path b
def Paths_c():
  path_c=tk.Toplevel()
  path_c.geometry("800x200")
  path_c["bg"]="black"
  label_c_=tk.Label(path_c,text=""" The Calisthenics class masters the art of bodyweight exercises, 
                    blending agility with strength to swiftly navigate the battlefield and strike with deadly precision. 
                    Agile and elusive, 
                    they excel at hit-and-run tactics, 
                    swiftly dispatching foes with a flurry of acrobatic moves.""",fg="#7d12ff",bg="black",font="calibri,12")
  label_c_.grid(column=0,row=0)


  
def Paths_b():
  path_b=tk.Toplevel()
  path_b.geometry("800x200")
  path_b["bg"]="black"
  label_b=tk.Label(path_b,text="""The Bodybuilder class excels in physical strength and endurance, 
                   capable of absorbing heavy damage while dishing out punishing blows. 
                   Masters of muscle and power, 
                   they dominate the battlefield with sheer force and resilience.""",fg="red",bg="black",font="calibri,12")
  label_b.grid(column=0,row=0)

  
#This opens the choose your path window

def open_CYP():
  
  if messagebox.askyesno(title="Choose Your Path",message="Do you want to choose PATH? "):
    ""
  else:
    choose_yp.destroy()
  choose_yp=tk.Toplevel()
  choose_yp.geometry("300x40")
  choose_yp["bg"]="black"
  choose_yp.title("Choose Your Path")
  choose_yp= tk.Label(choose_yp, text="Paths")
  choose_yp.grid(column=1,row=1)
  button_C=tk.Button(choose_yp, text= "Calisthenics",font="calibri",command=Paths_c)
  button_C.grid(column=2,row=1)
  button_C["bg"]="black"
  button_C["fg"]="#7d12ff"
  button_b=tk.Button(choose_yp, text= "Body Builder",font="calibri",command=Paths_b)
  button_b.grid(column=3,row=1)
  button_b["bg"]="black"
  button_b["fg"]="red"

button_1=tk.Button(window, text="Choose Your PATH", command= open_CYP)
button_1.grid(column=3,row=1)

button_1["fg"]="#7d12ff"
button_1["bg"]="black"

#Calorie Calculator
#This calculates your deficit
calorieDef_var=tk.StringVar()
def calculate_deficit():
  

  calculate_def=int(calorieDef_var.get())

  print("Calories for Deficit: "+ str(calculate_def*12-100))

#This calculates your surplus
calorieSup_var=tk.StringVar()

def calculate_surplus():
   calculate_sup=int(calorieSup_var.get())
   print("Calories for surplus: "+ str(calculate_sup*12+200))



#This opens the calorie calculator and where you add to values to the box
def open_Calorie_Calculator():

  Calorie_Calculator = tk.Toplevel()

  Calorie_Calculator.geometry("300x100")
  Calorie_Calculator["bg"] = "black"

  Calorie_Calculator.title("Calorie Calculator")
  entry_cal_d=tk.Entry(Calorie_Calculator,textvariable=calorieDef_var)
  entry_cal_d.grid(column=1,row=1)
  entry_cal_s=tk.Entry(Calorie_Calculator,textvariable=calorieSup_var)
  entry_cal_s.grid(column=1,row=2)
  button_d=tk.Button(Calorie_Calculator,text="Calculate Deficit",fg="blue",command=calculate_deficit)
  button_d.grid(column=2,row=1)
  button_s=tk.Button(Calorie_Calculator,text="Calculate Surplus",fg="red",command=calculate_surplus)
  button_s.grid(column=2,row=2)


button_2=tk.Button(window, text="Calorie Calculator", command=open_Calorie_Calculator)
button_2.grid(column=3,row=2)
button_2["fg"]="#7d12ff"
button_2["bg"]="black"


#About us 

#This opens new window and shows the About page
def open_About_us():

  About_us= tk.Toplevel()

  About_us.geometry("850x500")

  About_us.title("About")
  About_us["bg"]="black"
  label_ab=tk.Label(About_us,text="""
My SoLo app is inspired by the Korean manga Solo Leveling, where we follow protagainist Sung Jin Woo on his path to becoming the strongest hero. 
In this manga Sung Jin Woo levels up by working out.
he reason why I choose to use the manga as my inspiration is because of the sheer work ethic and determination that Jin Woo had.""",font=("calibri",10),bg="black",fg="#7d12ff")
  label_ab.grid()
  


button_3=tk.Button(window, text="About",command=open_About_us)
button_3.grid(column=3,row=3)
button_3["fg"]="#7d12ff"
button_3["bg"]="black"




window.mainloop()